const Discord = require('discord.js-selfbot-v13');
const { DiscordStreamClient } = require('discord-stream-client');
const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;
const ffmpeg = require('fluent-ffmpeg');
ffmpeg.setFfmpegPath(ffmpegPath);
const client = new Discord.Client();
new DiscordStreamClient(client);

client.on('ready', async client => {
  console.log('Ready!', client.user.tag);
  const channel = client.channels.cache.get('1192552061661880360');
  const connection = await client.streamClient.joinVoiceChannel(channel, {
    selfDeaf: true,
    selfMute: true,
    selfVideo: false,
  });
  const stream = await connection.createStream();
  const player = client.streamClient.createPlayer(
    'https://rr2---sn-hp57kndr.googlevideo.com/videoplayback?expire=1705471876&ei=JBunZf6FLOaBtQeO5aDICg&ip=2605%3A6400%3A40%3Afb66%3Ae817%3A46bf%3A5a8b%3Af3de&id=o-ACyjB2dWPf7t7bP4apIjdklclX8j2goZ4M-TrrcxoUXc&itag=18&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&mh=Ko&mm=31%2C29&mn=sn-hp57kndr%2Csn-hp57ynly&ms=au%2Crdu&mv=m&mvi=2&pl=48&initcwndbps=230000&spc=UWF9f-E-3m_OIBFkF2mWjDxYtHaJTz_otBWQ&vprv=1&svpuc=1&mime=video%2Fmp4&gir=yes&clen=513934587&ratebypass=yes&dur=7677.167&lmt=1687400121210099&mt=1705449893&fvip=2&fexp=24007246&c=ANDROID&txp=5538434&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Cgir%2Cclen%2Cratebypass%2Cdur%2Clmt&sig=AJfQdSswRQIgUpBu47Pum8YC-9PbqKD7PWiBzoIGOx99mXnfmGA6j1cCIQC-3rBGFl2uTd7DI_dOx4M7rgIvys2Rz3nX3DZNvdQrKw%3D%3D&lsparams=mh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Cinitcwndbps&lsig=AAO5W4owRQIhAKPXxDzJwcSyUqZpJt0xg_KGbv6J6HJIdQnYqB0pdou4AiBowoXl1OKAVouJj_EYlAqnt-BMxQiP0iDYtj0lRb0ROw%3D%3D&title=El+Motasawel+Movie+-+%D9%81%D9%8A%D9%84%D9%85+%D8%A7%D9%84%D9%85%D8%AA%D8%B3%D9%80%D9%88%D9%84',
    stream.udp,
  );
  player.on('error', err => console.error(err));
  player.play({
    kbpsVideo: 720, // FHD 60fps
    fps: 15,
    hwaccel: true,
    kbpsAudio: 128,
    volume: 1,
  });
});

client.login('MTE4MzcwNjQ5Mzk1OTI4NjgyNQ.GoNMIa.ZUbj10WQcSH3fQOFLs3li6AUUfvKSwWqMFN_zQ');